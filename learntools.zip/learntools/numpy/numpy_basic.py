import numpy as np

from learntools.core import *
from learntools.core.problem import *
from learntools.core.utils import *

## numpy 버전확인
class NumpyBasicQ1(EqualityCheckProblem):
    _var = 'version'
    _expected = np.__version__
    _hint = "__version__ 속성을 이용하세요."
    _solution = CS("""\
version = np.__version__
""")

## 모든 원소가 0인 array 생성
class NumpyBasicQ2(EqualityCheckProblem):
    _var = 'arr_zeros'
    _expected = (np.zeros(10),)
    _hint = "zeros() 함수를 이용하세요."
    _solution = CS("""\
arr_zeros = np.zeros(10)
""")

## 2차원 배열 만들기
class NumpyBasicQ3(EqualityCheckProblem):
    _var = 'arr2x2'
    _expected = (np.array([[1,2],[3,4]]),)
    _hint = "array() 함수를 이용하세요."
    _solution = CS("""\
arr2x2 = np.array([[1,2],[3,4]])
""")

## 형변환
class NumpyBasicQ4(EqualityCheckProblem):
    _var = 'arrfloat64'
    _expected = ([1.0, 2.0, 3.0, 4.0, 5.0],)
    _hint = "astype() 함수와 float64 타입을 이용하세요."
    _solution = CS("""\
arrfloat64 = arrint64.astype(np.float64)
""")

## 행렬 덧셈
class NumpyBasicQ5(EqualityCheckProblem):
    _var = 'arr3'
    _expected = ([6, 6, 6, 6, 6],)
    _hint = "+ 연산자를 사용하세요."
    _solution = CS("""\
arr3 = arr1 + arr2
""")

## 행렬 전치
class NumpyBasicQ6(EqualityCheckProblem):
    _var = 'arr_transpose'
    _expected = ([[0., 0.],
       [0., 0.],
       [0., 0.],
       [0., 0.],
       [0., 0.]],)
    _hint = "reshape() 함수를 이용하세요."
    _solution = CS("""\
arr_transpose = arr.reshape(5,2)
""")




qvars = bind_exercises(globals(), [
    NumpyBasicQ1,
    NumpyBasicQ2,
    NumpyBasicQ3,
    NumpyBasicQ4,
    NumpyBasicQ5,
    NumpyBasicQ6,
    ],
    )
__all__ = list(qvars)