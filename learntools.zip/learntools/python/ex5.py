from learntools.python.utils import bind_exercises
from learntools.python.problem import *
from learntools.python.richtext import *
import random
CS = CodeSolution

class EarlyExitDebugging(FunctionProblem):
    _var = 'has_lucky_number'

    _test_cases = [
            ([], False),
            ([7], True),
            ([14], True),
            ([3, 14], True),
            ([3, 21, 4], True),
            ([7, 7, 7], True),
            ([3], False),
            ([3, 4, 5], False),
    ]

    _hint = ("How many times does the body of the loop run for a list"
            " of length n? (If you're not sure, try adding a `print()`"
            " call on the line before the `if`.)")

    _solution = """return이 실행되면 즉시 해당 함수가 종료됩니다. 
    
    버그가 포함된 함수는 리스트의 모든 요소를 확인하기 전에 첫번째 요소가 체크 되고 리턴 되버립니다. 
    
    그러므로 아래와 같이 코드를 수정해야 합니다.
```python
def has_lucky_number(nums):
    for num in nums:
        if num % 7 == 0:
            return True
    # 우리는 행운의 숫자를 찾지 못하고 리스트 순회를 마쳤습니다.
    return False
```

아래 코드는 any() 함수와 list comprehension 을 이용한 코드입니다.

```python
def has_lucky_number(nums):
    return any([num % 7 == 0 for num in nums])
```
"""

class ElementWiseComparison(FunctionProblem):
    _var = 'elementwise_greater_than'

    _test_cases = [
            ( ([1, 2, 3, 4], 2), [False, False, True, True] ),
            ( ([1, 2, 3, 4], 5), [False, False, False, False] ),
            ( ([], 2), [] ),
            ( ([1, 1], 0), [True, True] ),
    ]

    _hint = ("for in 문이나 range 함수 등을 사용하세요.")

    _solution = """답은 아래와 같습니다.
```python
def elementwise_greater_than(L, thresh):
    res = []
    for ele in L:
        res.append(ele > thresh)
    return res
```

아래 코드는 list comprehension을 사용한 간략 버전입니다.
```python
def elementwise_greater_than(L, thresh):
    return [ele > thresh for ele in L]
```
"""

class BoringMenu(FunctionProblem):
    _var = 'menu_is_boring'

    _test_cases = [
            ( ['Egg', 'Spam',], False),
            ( ['Spam', 'Eggs', 'Bacon', 'Spam'], False),
            ( ['Spam', 'Eggs', 'Spam', 'Spam', 'Bacon', 'Spam'], True),
            ( ['Spam', 'Spam'], True),
            ( ['Lobster Thermidor aux crevettes with a Mornay sauce, garnished with truffle pâté, brandy and a fried egg on top', 'Spam'], False),
            ( ['Spam'], False),
            ( [], False),
    ]

    _hint = ("len()함수로 리스트의 길이를 구하고, range() 함수를 사용하여 리스트의 인덱스의 범위를 구합니다. 점검할 요소와 그 다음 요소의 값을 비교하세요.")

    # TODO: I don't think I want to mention any of the more 'clever' solutions involving zip or itertools. Though it depends on whether
    # we end up covering zip in the tutorial notebook.
    _solution = """

```python
def menu_is_boring(meals):
    # Iterate over all indices of the list, except the last one
    for i in range(len(meals)-1):
        if meals[i] == meals[i+1]:
            return True
    return False
```

"""

# Analytic solution for expected payout =
# .005 * 100 + (.05 - .005) * 5 + (.25 - .05) * 1.5
def play_slot_machine():
    r = random.random()
    if r < .005:
        return 100
    elif r < .05:
        return 5
    elif r < .25:
        return 1.5
    else:
        return 0

class ExpectedSlotsPayout(ThoughtExperiment):
    #_var = 'estimate_average_slot_payout'
    _solution = """
    
    이 대답을 얻으려면 슬롯 머신을 n_runs번 당기는 것을 시뮬레이션하기 위해 
    Estimate_average_slot_payout(n_runs) 함수를 구현해야 합니다. 
    해당 n_runs에 대한 평균 지불금을 반환해야 합니다.

    그런 다음 함수가 정의되면 평균 슬롯 지불금을 추정하기 위해 함수를 호출하기만 하면 됩니다.
    결과의 높은 분산 때문에 실제 기대에 가까운 안정적인 응답을 얻으려면,
    매우 높은 n_runs 값으로 함수를 실행해야 할 수도 있습니다. 
    예를 들어, 1000000의 n_runs 값을 사용할 수 있습니다.
    다음은 함수의 모양에 대한 예입니다.

    그런 다음 함수가 정의되면 평균 슬롯 지불금을 추정하기 위해 함수를 호출하기만 하면 됩니다.


    def estimate_average_slot_payout(n_runs):
        # 슬롯 머신에서 n_runs 실행하고, 각각의 지불금을 계산합니다.
        payouts = [play_slot_machine()-1 for i in range(n_runs)]
        # 지불금의 평균 값을 계산합니다.
        avg_payout = sum(payouts) / n_runs
        return avg_payout
        
    """

class SlotsSurvival(FunctionProblem):
    _var = 'slots_survival_probability'
    
    _solution = CS("""def slots_survival_probability(start_balance, n_spins, n_simulations):
    # How many times did we last the given number of spins?
    successes = 0
    # A convention in Python is to use '_' to name variables we won't use
    for _ in range(n_simulations):
        balance = start_balance
        spins_left = n_spins
        while balance >= 1 and spins_left:
            # subtract the cost of playing
            balance -= 1
            balance += play_slot_machine()
            spins_left -= 1
        # did we make it to the end?
        if spins_left == 0:
            successes += 1
    return successes / n_simulations""")

    def _do_check(cls, fn):
        actual = fn(10, 10, 1000)
        assert actual == 1.0, "Expected slots_survival_probability(10, 10, 1000) to be 1.0, but was actually {}".format(repr(actual))
        
        actual = fn(1, 2, 10000)
        assert .24 <= actual <= .26, "Expected slots_survival_probability(1, 2, 10000) to be around .25, but was actually {}".format(repr(actual))

        actual = fn(25, 150, 10000)
        assert .22 <= actual <= .235, "Expected slots_survival_probability(25, 150, 10000) to be around .228, but was actually {}".format(repr(actual))


qvars = bind_exercises(globals(), [
    EarlyExitDebugging,
    ElementWiseComparison,
    BoringMenu,
    ExpectedSlotsPayout,
    SlotsSurvival,
    ],
)
__all__ = list(qvars) + ['play_slot_machine']
