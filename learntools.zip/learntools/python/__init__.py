from learntools.python.globals_binder import binder
