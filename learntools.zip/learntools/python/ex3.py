from learntools.python.utils import bind_exercises, format_args
from learntools.python.problem import *
from learntools.python.richtext import *
from learntools.python.blackjack import BlackJack
CS = CodeSolution

class SignFunctionProblem(FunctionProblem):
    _var = 'sign'
    _hint = "if, elif, else 문을 사용해보세요."
    _test_cases = [
            (-1, -1),
            (-100, -1),
            (-.001, -1),
            (0, 0),
            (0.0, 0),
            (0.001, 1),
            (1, 1),
            (1812, 1),
    ]

    _solution = CS(
"""def sign(x):
    if x > 0:
        return 1
    elif x < 0:
        return -1
    else:
        return 0""")

# TODO: could try to intercept stdout to actually check this I guess?
class PluralizationProblem(ThoughtExperiment):

    _solution = """가장 간단한 방법은 print 함수를 다음과 같이 바꾸는 겁니다.:

```python
if total_candies == 1:
    print("1개의 사탕을 나누면, ")
else:
    print(total_candies, "개의 사탕들을 나누면, ")
```

더 간략하게 줄이면 아래 코드처럼 작성 할 수 있습니다.

```python
print("total_candies, "사탕을 나누면, " if total_candies == 1 else "사탕들을 나누면,")
```"""

class WeatherDebug(VarCreationProblem):

    _vars = ['have_umbrella', 'rain_level', 'have_hood', 'is_workday']
    # Default VarCreationProblem logic says that if any vars haven't changed
    # from their initial/default values then the problem isn't attempted. Which
    # doesn't work here...
    #_default_values = [True, 0.0, True, True]

    _hint = ("Take a look at how we fixed our original expression in the main"
            " lesson. We added parentheses around certain subexpressions. "
            "The bug in this code is caused by Python evaluating certain operations "
            "in the \"wrong\" order.")

    _solution = """에러를 발생하는 케이스로 다음을 들 수 있습니다.

```python
have_umbrella = False
rain_level = 0.0
have_hood = False
is_workday = False
```

분명히 우리는 이 경우 날씨에 대비하고 있습니다. 
비가 오지 않아 뿐만 아니라, 근무일이 아니므로 집을 나갈 필요도 없습니다! 
그러나 우리 함수는 이러한 입력에 대해 False를 반환합니다.

문제는 파이썬 코드는 우선 순위를 아래와 같이 판단한다는 겁니다. 

```python
(not (rain_level > 0)) and is_workday
```
우리가 표현하고 싶었던 식은 아래와 같습니다.

```python
not (rain_level > 0 and is_workday)
```
"""

    @staticmethod
    def canonical_prepared(have_umbrella, rain_level, have_hood, is_workday):
        return (have_umbrella or
                       (rain_level < 5 and have_hood) or
                        not (rain_level > 0 and is_workday)
                       )
    @staticmethod
    def ill_prepared(have_umbrella, rain_level, have_hood, is_workday):
        return have_umbrella or rain_level < 5 and have_hood or not rain_level > 0 and is_workday

    def _do_check(cls, *args):
        expected = cls.canonical_prepared(*args)
        actual = cls.ill_prepared(*args)
        assert actual != expected, ("주어진 {}, `prepared_for_weather` 함수는"
                " `{}`를 리턴합니다. 하지만 그게 맞다고 생각합니다.. (We want inputs that lead to"
                " `prepared_for_weather` 함수에 잘못된 결과로 이어지는 입력을 원합니다.)").format(
                        format_args(cls.ill_prepared, args),
                        repr(actual),
                        )


class ConciseIsNegative(FunctionProblem):
    # NB: looks like there's no clean way to check for single-line-ness. 
    # But they'll know whether they've accomplished it or not, and there's not much
    # point in cheating.

    _var = 'concise_is_negative'

    _test_cases = [
            (1, False),
            (0, False),
            (-100, True),
    ]

    _hint = ("`number < 0` 이면 `True`을 리턴합니다.")
    _solution = CodeSolution("return number < 0")

class AllToppings(FunctionProblem):
    _var = 'wants_all_toppings'

    _hint = "`and` 연산자를 사용하세요."
    _solution = CodeSolution("return ketchup and mustard and onion")

    _test_cases = [
            ((True, True, True), True),
            ((False, True, True), False),
            ((False, False, False), False),
            ((True, False, True), False),
            ((True, True, False), False),
    ]

class PlainDog(FunctionProblem):
    _var = 'wants_plain_hotdog'

    _hint = "`not` 연산자를 이용하세요."
    _solution = (
"""해결 방법 중 하나는 아래 처럼 and 연산자를 활용하는 것입니다.
```python
return not ketchup and not mustard and not onion
```
아래 방법도 사용가능합니다. 
```python
return not (ketchup or mustard or onion)
```""")

    _test_cases = [
            ((True, True, True), False),
            ((False, True, True), False),
            ((False, False, False), True),
            ((True, False, True), False),
            ((False, False, True), False),
            ((False, True, False), False),
    ]

class OneSauce(FunctionProblem):
    _var = 'exactly_one_sauce'

    _hint = ("zreturn (케찹 좋아요 and 머스타드 싫어요) or (케찹 싫어요 and 머스타드 좋아요")
    _solution = CodeSolution("return (ketchup and not mustard) or (mustard and not ketchup)")

    _test_cases = [
            ((True, True, True), False),
            ((False, True, True), True),
            ((False, False, False), False),
            ((True, False, True), True),
    ]

HotDogGauntlet = MultipartProblem(
        AllToppings, PlainDog, OneSauce,
        )

class OneTopping(FunctionProblem):
    _var = 'exactly_one_topping'

    _hint = ("int() 함수를 사용해서 int(참) 는 1이 됩니다. 그리고 `int(False)`는 0이 됩니다."
            "`ketchup`, `mustard`, `onion`을 integer 형으로 변환하여 계산해보세요."
            )
    _solution = ("""`and`, `or` and `not` 연산자만 사용하면 매우 복잡해집니다. bool 변수를 int 변수로 형변환을 하면 매우 간략하게 됩니다 :
```python
return (int(ketchup) + int(mustard) + int(onion)) == 1
```

실은 int 함수를 몰라도, 파이썬의 특성을 알면 해결 할 수 있습니다. 
아래 처럼 코드를 작성하면 파이썬은 숫자형으로 변환합니다.

```python
return (ketchup + mustard + onion) == 1
```""")
    
    _test_cases = [
            ((True, True, True), False),
            ((False, True, True), False),
            ((False, False, False), False),
            ((True, False, True), False),
            ((False, False, True), True),
    ]

class BlackJackProblem(Problem):
    _var = 'should_hit'



    # TODO: would nice to have an injection decorator for this kind of thing,
    # but I'm not sure how well it would work with the existing magical
    # metaclass method decoration :/
    def simulate_one_game(cls):
        phit = cls._get_injected_args()[0]
        game = BlackJack(phit, True)
        game.play()

    def simulate(cls, n_games=100):
        phit = cls._get_injected_args()[0]
        wins = 0
        for _ in range(n_games):
            wins += 1 == BlackJack(phit).play()
        print("Player won {} out of {} games (win rate = {:.1%})".format(
            wins, n_games, wins/n_games
            ))

qvars = bind_exercises(globals(), [
    SignFunctionProblem,
    PluralizationProblem,
    WeatherDebug,
    ConciseIsNegative,
    HotDogGauntlet,
    OneTopping,
    BlackJackProblem,
    ],
)
__all__ = list(qvars)
