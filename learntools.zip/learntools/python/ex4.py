from learntools.python.utils import bind_exercises
from learntools.python.problem import *
from learntools.python.richtext import *
CS = CodeSolution

# Complete fn that takes a list and returns the second element

class SelectSecondItem(FunctionProblem):
    #TODO: Wrap index errors
    _var = 'select_second'

    _test_cases = [
            ([1, 2, 3], 2),
            ([[1], [2], [4]], [2]),
            (list(range(10)), 1),
            ([1], None),
            ([], None),
    ]

    _hint = "인덱스는 0부터 시작합니다..  두번째 요소는 리스트[1] 입니다."

    _solution = CS(
"""def select_second(L):
    if len(L) < 2:
        return None
    return L[1]""")

class LosingTeamCaptain(FunctionProblem):
    _var = 'losing_team_captain'

    _test_cases = [
            ([["Paul", "John", "Ringo", "George"]], "John"),
            ([["Paul", "John", "Ringo", "George"], ["Jen", "Jamie"]], "Jamie"),
            ([["Who", "What", "I don't Know", "I'll tell you later"], ["Al", "Bonnie", "Clyde"]], "Bonnie"),
    ]

    _hint = ("이차원 리스트로 표현될 수 있습니다. 예) L[][] "
             "마지막 팀은 `L[-1]` 로 찾을 수 있으며, ."
             "코치는L[팀인덱스][0], 주장은L[팀인덱스][1]에 위치해 있습니다."
             )

    _solution = CS(
"""def losing_team_captain(teams):
    return teams[-1][1]""")

class PurpleShell(FunctionProblem):

    _var = 'purple_shell'


    _hint = ("temp 변수를 추가해서 리스트의 첫 요소와 마지막 요소를 바꾸세요. "
            )

    def _do_check(cls, fn):
        lists = (["M","L"],
                 ["M","L","J"],
                 [1,2,3,4,5]
                )
        def sol_fn(x): x[0], x[-1] = x[-1], x[0]
        for l in lists:
            copy_for_soln_fn = l.copy()
            copy_for_user_fn = l.copy()
            sol_fn(copy_for_soln_fn) # create desired output for comparison
            user_output = fn(copy_for_user_fn) # also applies swap in this line
            assert(type(user_output) == type(None)), ("인자로 받은 리스트를 변경해야할 뿐만 아니라, 아무것도 리턴하지 말아야 합니다."
                                                      "첫째날 실습에 사용했던 스왑 함수 문제를 참고하세요.")
            assert copy_for_user_fn == copy_for_soln_fn, (
                    "{} 리스트를 인자로 함수를 실행하면, {} 결과가 예상되지만, "
                    " 실제로는 {} 결과가 나왔습니다.").format(repr(l), repr(copy_for_soln_fn), repr(copy_for_user_fn))



    _solution = CS(
"""def purple_shell(racers):
    # temp 변수를 사용해서 값을 바꾸세요. 
    temp = racers[0]
    racers[0] = racers[-1]
    racers[-1] = temp""")

class UnderstandLen(VarCreationProblem):
    _var = 'lengths'
    _expected = [3, 2, 0, 2]
    _default_values = [ [] ]

    _hint = "len() 함수를 사용해서 길이를 확인하세요."

    _solution = (
            """
- a: a 리스트에는 3개의 요소가 있습니다. 
- b: b 리스트에 있는 `[2, 3]` 요소는 한 개의 요소로 봅니다. 그래서 총 2개의 요소가 있습니다. 
- c: c 리스트는 빈 리스트이기 때문에, 0
- d: [1, 2, 3][1:] 는 `[2, 3]` 과 같습니다. 따라서 d 리스트는 총 2개의 요소를 가지고 있습니다.""")

class FashionablyLate(FunctionProblem):
    _var = 'fashionably_late'



    _test_cases = [
            ((['Adela', 'Fleda', 'Owen', 'May', 'Mona', 'Gilbert', 'Ford'], "Adela"), False),
            ((['Adela', 'Fleda', 'Owen', 'May', 'Mona', 'Gilbert', 'Ford'], "Fleda"), False),
            ((['Adela', 'Fleda', 'Owen', 'May', 'Mona', 'Gilbert', 'Ford'], "Owen"), False),
            ((['Adela', 'Fleda', 'Owen', 'May', 'Mona', 'Gilbert', 'Ford'], "May"), False),
            ((['Adela', 'Fleda', 'Owen', 'May', 'Mona', 'Gilbert', 'Ford'], "Mona"), True),
            ((['Adela', 'Fleda', 'Owen', 'May', 'Mona', 'Gilbert', 'Ford'], "Gilbert"), True),
            ((['Adela', 'Fleda', 'Owen', 'May', 'Mona', 'Gilbert', 'Ford'], "Ford"), False),
            ((["Paul", "John", "Ringo", "George"], "John"), False),
            ((["Paul", "John", "Ringo", "George"], "Ringo"), True),
            ((["Lebron", "Kevin"], "Lebron"), False),
            ((["Lebron", "Kevin"], "Kevin"), False),
    ]

    _hint = ("손님이 몇번째 도착했는지는 리스트 타입의 메소드인 .index() 함수를 사용하세요."
            "총 인원을 알기 위해서는 len() 함수를 사용하세요."
            "인덱싱은 0부터 시작한다는 것을 기억하세요."
             )

    _solution = CS(
"""def fashionably_late(arrivals, name):
    order = arrivals.index(name)
    return order >= len(arrivals) / 2 and order != len(arrivals) - 1""")

class CountNegativesRiddle(FunctionProblem):
    _var = 'count_negatives'

    _test_cases = [
            ([], 0),
            ([0, -1, -1], 2),
            ([3, -3, 2, -1, 4, -4, 5, 5], 3),
            ([1, 2, 3, 4, 5, 0], 0),
    ]

    _hint = ('Can you think of a way you could solve this problem if the input list'
            ' was guaranteed to be sorted and guaranteed to contain 0?')

    _solution = """
다음은 해결 방법 중 하나입니다.
```python
def count_negatives(nums):
    # nums 리스트에 0을 추가합니다.
    nums.append(0)
    # sorted 함수를 사용하면 요소들이 오름차순으로 정렬됩니다. 
    nums = sorted(nums)
    # 오른차순으로 정렬했기 때문에, 0 보다 작은 값들은 0이 있는 요소보다 왼쪽에 있을 겁니다. 
    # 인덱스로 따지면, 0이 위치한 인덱스 보다 값이 작습니다. 
    # 예)          -2,  -1, 0,  1,  2
    # 인덱스 번호   [0] [1] [2] [3] [4]
    # 0이 위치한 인덱스 번호는 0보다 작은 수의 총 수와 같게 됩니다. 
    return nums.index(0)
```

아래는 재귀 호출이라는 방법을 활용한 코드입니다. 
리스트의 맨 앞에 있는 값을 하나식 점검합니다. 
(nums[0] < 0) 보다 작은지 체크 합니다. True 이면 1로 인식이 됩니다. 
((nums[0] < 0) 식 뒤에 + 연산자가 위치하기 때문입니다.)
첫번째 값을 뺀 나머지 리스트를 인자로 함수를 다시 호출합니다. 
하나씩 값을 비교하다, 최종적으로 nums 리스트의 끝까지 도달하면 0을 리턴합니다. 
끝까지 가면 다시 호출했던 함수로 다시 돌아 오게 되고, (nums[0] < 0) 만족하는 수를 세게 됩니다.  

참고로 재귀함수를 설명한 사이트를 안내드립니다. 
https://www.programiz.com/python-programming/recursion

```python
def count_negatives(nums):
    if not nums:
        return 0
    else:
        return (nums[0] < 0) + count_negatives(nums[1:])
```"""


qvars = bind_exercises(globals(), [
    SelectSecondItem,
    LosingTeamCaptain,
    PurpleShell,
    UnderstandLen,
    FashionablyLate,
    CountNegativesRiddle,
    ],
)
__all__ = list(qvars)
