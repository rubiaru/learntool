import random

from learntools.python.utils import bind_exercises
from learntools.python.problem import *
from learntools.python.richtext import *
CS = CodeSolution

import learntools.python.solns.jimmygraph as jg_module
import learntools.python.solns.blackjack_gt as bj_module
hand_gt_soln = bj_module.blackjack_hand_greater_than

class JimmySlots(ThoughtExperiment):
    _solution = CS.load(jg_module.__file__)


class LuigiAnalysis(ThoughtExperiment):
    _hint = ("고려해야 할 몇 가지 사항:\n\n"
            "- 변수 i의 유형은 무엇입니까?\n"
            "- 가져온 full_dataset 목록을 검사하면 어떻게 됩니까?"
            "  (실제로 그렇게 크지는 않습니다.)"
            "  오류를 일으키는 레이서를 찾을 수 있습니까?"
            )

    _solution = '''Luigi는 변수 이름 i를 사용하여 racer['items']의 각 항목을 나타냅니다. 

그러나 그는 외부 루프에 대한 루프 변수로도 i를 사용했습니다.
- (for i in range(len(racers))). 

이것들은 서로를 망치고 있습니다. 

내부 및 외부 루프에 대해 다른 루프 변수를 사용하여 이 문제를 해결할 수 있습니다. 

for item in racer['items'] 코드가 더 읽기 쉽습니다.

이와 같은 가변 섀도잉 버그는 자주 발생하지 않지만 발생하면 진단하는 데 엄청난 시간이 걸릴 수 있습니다!
'''

def gen_bj_hand():
    cards = list(map(str, range(1, 11))) + ['J', 'Q', 'K', 'A']
    ncards = random.randint(1, 6)
    hand = [random.choice(cards) for _ in range(ncards)]
    return hand

def gen_bj_inputs(n):
    random.seed(1)
    return [
            (gen_bj_hand(), gen_bj_hand())
            for _ in range(n)
            ]

class BlackjackCmp(FunctionProblem):
    _var = 'blackjack_hand_greater_than'
    _hint = ("This problem is a lot easier to solve if you define at least one 'helper' function."
            " The logic for calculating a hand's total points is a good candidate for extracting into a helper function."
            )
    _solution = CS.load(bj_module.__file__)

    _test_cases = [
            (args, hand_gt_soln(*args))
            for args in gen_bj_inputs(100)
            ]


qvars = bind_exercises(globals(), [
    JimmySlots,
    LuigiAnalysis,
    BlackjackCmp,
    DummyProblem,
    ], start=1,
)
__all__ = list(qvars)
