from learntools.python.utils import bind_exercises
from learntools.python.problem import *
from learntools.python.richtext import *


# q0 연습문제
class ExerciseFormatTutorial(VarCreationProblem):
    _var = 'color'
    _expected = 'blue'

    _hint = "Your favorite color rhymes with *glue*."
    _solution = CodeSolution('color = "blue"')

    def _correct_message(cls):
        if not cls._hinted and not cls._peeked:
            return ("세상에 힌트도 없이 답을 맞춘거에요?"
                    " 대다나다.=_=b"
                    )
        return ''

    def _failure_message(cls, var, actual, expected):
        if (
                any(actual.endswith(suff) for suff in ['oo', 'ue', 'ew'])
                and actual.strip().lower() != 'blue'
            ):
            return "후훗 잼있군요."
        elif actual.strip(' .!').lower() == 'ni':
            return "Please! Please! No more! We will find you a shrubbery."
        return ("{} is not your favorite color!"
                " Well, maybe it is, but we're writing the rules. The point"
                " of this question is to force you to get some practice asking"
                " for a hint. Go ahead and uncomment the call to `q0.hint()`"
                " in the code cell below, for a hint at what your favorite color"
                " *really* is.").format(actual)

# q1 원의 넓이는 구하는 문제
class CircleArea(VarCreationProblem):
    _vars = ['radius', 'area']
    _expected = [3/2, (3/2)**2 * 3.14159]

    _hint = "제곱 ' a ** b '라고 표현합니다."
    _solution = CodeSolution('radius = diameter / 2',
            'area = pi * radius ** 2')
# q2 
class VariableSwap(Problem):

    _hint = "세번째 변수를 만들어 사용하세요."
    _solution = """가장 일반적인 방법은 세번째 임시 변수를 만들어 이전 값 중 하나를 임시로 저장하는 것입니다.:

    tmp = a
    a = b
    b = tmp

파이썬 공부를 많이 한 사람이라면, 한 중에 두 개의 변수를 바꾸는 다음 트릭을 보았을 겁니다. :

    a, b = b, a

튜플에 대해 다룰 때, 다시 다루겠습니다."""

    def store_original_ids(cls):
        cls.id_a = id(G['a'])
        cls.id_b = id(G['b'])

    def _do_check(cls):
        ida = id(G['a'])
        idb = id(G['b'])
        orig_values = [1, 2, 3], [3, 2, 1]
        a, b = G['a'], G['b']
        if ida == cls.id_b and idb == cls.id_a:
            return
        assert not (ida == cls.id_a and idb == cls.id_b), ("`a` and `b` 변수 모두 "
                "처음 설정된 값을 가지고 있습니다.")
        orig_ids = (cls.id_a, cls.id_b)
        if (b, a) == orig_values:
            # well this is ridiculous in its verbosity
            assert False, (
        "혹시 이런 방법으로 쓰셨나요?\n"
        "```python\na = [3, 2, 1]\nb = [1, 2, 3]```\n?\n"
        "위와 같은 방법이 가능하겠지만, 원하는 답의 방향이 아닙니다."
        )
        assert ida in orig_ids, ("a 변수에 이상한 것이 할당 되었습니다. ")
        assert idb in orig_ids, ("b 변수에 이상한 것이 할당 되었습니다. ")
        assert ida != idb, "b와 a가 같습니다. 둘 모두 이런 값을 가지고 있습니다. : `{}`".format(
                repr(G['a']))
        assert False, "예상치 못한 답이네요. 조언을 드릴 수가 없습니다.."

# q3 . a
# It's an interesting question whether to make these parens questions checkable.
# Making them non-checkable for now.
class ArithmeticParensEasy(ThoughtExperiment):

    _hint = ('연산자에는 우선 순위가 있다고 배웠습니다.,'
            ' 나눗셈 연산자가 우선 순위가 높기 때문에 3/2 를 먼저 계산하고, 5에서 결과를 뺍니다.'
            ' 우선 순위를 바꾸기 위해서 괄호를 추가하세요.')
    _solution = CodeSolution("(5 - 3) // 2")
# q3 . b
class ArithmeticParensHard(ThoughtExperiment):

    _hint = '여러 쌍의 괄호를 사용해야할 수도 있습니다.'
    _solution = "`(8 - 3) * (2 - (1 + 1))` => 답안 중 하나입니다. 다른 답도 있을 수 있습니다."

ArithmeticParens = MultipartProblem(ArithmeticParensEasy, ArithmeticParensHard)

# q4 
class CandySplitting(VarCreationProblem):
    _var = 'to_smash'
    _expected = (121 + 77 + 109) % 3
    _default_values = [-1]

    _hints = [
            "나눗셈의 나머지를 구하는 연산자는 `%`입니다.",
            "나눗셈의 몫을 구하는 연산자는 `/`입니다.",
    ]
    _solution = CodeSolution("(alice_candies + bob_candies + carol_candies) % 3")

# q 5
class MysteryExpression(VarCreationProblem): 
    _var = 'ninety_nine_dashes'
    _expected = 4

    _hint = ("7---3에서 -문자를 줄여가면서 값을 확인하시고, -가 99개인 경우 값을 예측해보세요.")
    _solution = """7----3의 값은 `10`입니다. 우선 간단히 7--3을 보겠습니다.
    7--3은 `7-(-3)` 의미와 같습니다. 결국 값은 10이 됩니다. 
    7---3은 7-(-(-3)) 이므로 값이 4가 됩니다. 
    - 가 99개라는 뜻은 98개는 상쇄되고, 7-3과 결과가 같게 됩니다. 그래서 값은 4입니다.
"""

class QuickdrawGridProblem(ThoughtExperiment):
    _hint = """There are a few ways to solve this. Of the tools we've talked about so far, `//` and `%` (the integer division and modulo operators) and the `min` function may be useful."""
    _solution = """Here's one possible solution:
```python
rows = n // 8 + min(1, n % 8)
cols = min(n, 8)
height = rows * 2
width = cols * 2
```
Calculating `rows` is the trickiest part. Here's another way of doing it:
```python
rows = (n + 7) // 8```
We haven't shown the `math` module, but if you're familiar with the ceiling function, you might find this approach more intuitive:
```python
import math
rows = math.ceil(n / 8)
rows = int(rows) # ceil returns a float```
"""

# TODO: mention side effects.
class SameValueInitializationRiddle(ThoughtExperiment):

    _hints = [
            "You're unlikely to see any practical difference when the value we're initializing to is an int. But think about other Python types you're familiar with...",
            """`a = b = <expression>` is equivalent to...
```python
b = <expression>
a = b```""",
    ]

    _solution = """The one-line syntax results in `a` and `b` having the same memory address - i.e. they refer to the same object. This matters if that object is of a **mutable** type, like list. Consider the following code:
```python
odds = evens = []
for i in range(5):
    if (i % 2) == 0:
        evens.append(i)
    else:
        odds.append(i)
print(odds)
print(evens)```

We might expect this would print `[1, 3]`, then `[0, 2, 4]`. But actually, it will print `[0, 1, 2, 3, 4]` twice in a row. `evens` and `odds` refer to the same object, so appending an element to one of them appends it to both of them. This is occasionally the source of hair-pulling debugging sessions. :)

Another consideration is expressions that have side effects. For example, `list.pop` is a method which removes and returns the final element of a list. If we have `L = [1, 2, 3]`, then `a = b = L.pop()`, will result in `a` and `b` both having a value of 3. But running `a = L.pop()`, then `b = L.pop()` will result in `a` having value 3 and `b` having value 2.
"""


qvars = bind_exercises(globals(), [
    ExerciseFormatTutorial,
    CircleArea,
    VariableSwap,
    ArithmeticParens,
    CandySplitting,
    MysteryExpression,
    QuickdrawGridProblem,
    SameValueInitializationRiddle,
    ],
    start=0,
    )
__all__ = list(qvars)
