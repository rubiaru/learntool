import itertools

from learntools.python.utils import bind_exercises
from learntools.python.problem import *
from learntools.python.richtext import *
CS = CodeSolution

import learntools.python.solns.word_search as word_search_module
word_search = word_search_module.word_search
import learntools.python.solns.multi_word_search as mws_module
multi_word_search = mws_module.multi_word_search
import learntools.python.solns.diamond as d_module
diamond = d_module.diamond
import learntools.python.solns.roulette_analysis as rou_module
roulette_gt = rou_module.conditional_roulette_probs

class ZA(VarCreationProblem):
    _var = 'length'
    _default_values = [-1]
    _expected = 0
    _solution = ("비어있는 문자열의 길이는 0입니다."
                 "파이썬에서 빈 문자열은 bool로 형변환 시, 유일하게 False로 간주되는 문자열입니다.")
class ZB(VarCreationProblem):
    _var = 'length'
    _default_values = [-1]
    _expected = 7
    _solution = ("파이선에서는 문자열의 길이을 잴 때, 빈칸이나 구두점들도 포함 시킵니다.")
class ZC(VarCreationProblem):
    _var = 'length'
    _default_values = [-1]
    _expected = 7
    _solution = ("백슬래시는 특수문자로 길이에 영향을 주지 않습니다.")
class ZD(VarCreationProblem):
    _var = 'length'
    _default_values = [-1]
    _expected = 3
    _solution = ("해당 문자열은 hey와 완전히 같습니다.")
class ZE(VarCreationProblem):
    _var = 'length'
    _default_values = [-1]
    _expected = 1
    _solution = ("개행 문자는 단일 문자입니다! (비록 두 문자의 조합을 사용하여 파이썬으로 표현하지만.)")

LightningLen = MultipartProblem(
        ZA,ZB,ZC,ZD,ZE,
        )

class ZipValidator(FunctionProblem):
    _var = 'is_valid_zip'

    _hint = ("`help(str.isdigit)` 를 실행해보세요.")

    _solution = CS(
"""def is_valid_zip(zip_str):
    return len(zip_str) == 5 and zip_str.isdigit()""")

    _test_cases = [
            ('12345', True),
            ('1234x', False),
            ('1234', False),
            ('00000', True),
            ('', False),
            ('?', False),
    ]

class WordSearch(FunctionProblem):
    _var = 'word_search'

    _solution = CS.load(word_search_module.__file__)

    _hint = ("`str.split()`, `str.strip()`,  `str.lower()` 함수를 활용하여 코드를 작성하세요."
            )

    _test_docs_a = [
            "The Learn Python Challenge Casino",
            "They bought a car, and a horse",
            "Casinoville?",
    ]
    _test_docs_b = _test_docs_a + ["He bought a casino. That's crazy."]

    _test_inputs = [
            (_test_docs_a, 'casino'),
            (_test_docs_a, 'ear'),
            (_test_docs_a, 'car'),
            (_test_docs_b, 'crazy'),
            (_test_docs_b, 'bought'),
            ([], 'spam'),
    ]
    _test_cases = [
            (args, word_search(*args))
            for args in _test_inputs
    ]


class MultiWordSearch(FunctionProblem):
    _var = 'multi_word_search'
    _solution = CS.load(mws_module.__file__)

    _test_docs_a = [
            "The Learn Python Challenge Casino",
            "They bought a car",
            "Casinoville?",
    ]
    _test_docs_b = _test_docs_a + ["He bought a casino. That's crazy."]
    _test_keywords = [
            [],
            ['casino'],
            ['casino', 'ear'],
            ['casino', 'ear', 'bought'],
    ]

    _test_cases = [
            (args, multi_word_search(*args))
            for args in itertools.product(
                [_test_docs_a, _test_docs_b, []],
                _test_keywords,
                )
            ]


class DiamondArt(FunctionProblem):
    _var = 'diamond'

    _solution = CS.load(d_module.__file__)

    _hint = ("`str` has a few methods that help with the problem of padding"
            " a string to a certain size: two that might help here are"
            " `str.rjust()` or `str.center()`"
            )

    _test_heights = [2, 4, 0, 6]
    _test_cases = [
            (h, diamond(h))
            for h in _test_heights
            ]

    def _do_check(cls, fn):
        for args, expected in cls._test_cases:
            orig_args = args
            # Wrap in tuple if necessary
            if not isinstance(args, tuple):
                args = args,
            try:
                actual = fn(*args)
            except Exception as e:
                actual = e

            assert actual is not None, ("Got a return value of `None`"
                    " given height = {}."
                    " Did you forget the return statement?").format(args[0])
            orig_actual = actual
            # Ignore spaces to the right of the diamond itself for purposes
            # of comparison.
            # Also, okay, fine, allow final newline in their answer. I guess.
            if len(actual) > 0 and actual[-1] == '\n':
                actual = actual[:-1]
            normalize = lambda di: '\n'.join(line.rstrip() for line in di.split('\n'))
            anorm = normalize(actual)
            enorm = normalize(expected)
            actual_shown = (
                    repr(orig_actual) if (orig_actual + ' ').isspace()
                    else actual
                    )
            assert anorm == enorm, (
                    "Expected diamond looking something like...\n\n"
                    "```\n{}\n```\n for height={}, but instead got this thing...\n\n"
                    "```\n{}\n```\n").format(
                            expected,
                            args[0],
                            actual_shown,
                            )

class RouletteAnalyzer(FunctionProblem):
    _var = 'conditional_roulette_probs'

    _solution = CS.load(rou_module.__file__)

    _test_inputs = [
            [1, 3, 1, 5, 1],
            [1, 1, 1, 1,],
            [1, 2, 1],
            [5, 1, 3, 1, 2, 1 , 3, 3, 5, 1, 2],
    ]

    _test_cases = [
            (args, roulette_gt(args))
            for args in _test_inputs
            ]


qvars = bind_exercises(globals(), [
    LightningLen,
    ZipValidator,
    WordSearch,
    MultiWordSearch,
    DiamondArt,
    RouletteAnalyzer
    ], start=0,
)
__all__ = list(qvars)
