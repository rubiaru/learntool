from learntools.python.utils import bind_exercises
from learntools.python.problem import *
from learntools.python.richtext import *
CS = CodeSolution

class RoundFunctionProblem(FunctionProblem):
    _var = 'round_to_two_places'

    # TODO: Maybe should give a special message if they've modified the function body
    # but they don't have a return statement?

    _test_cases = [
            (1.000001, 1.00),
            (1.23456, 1.23),
    ]
    _hint = ("파이썬은 `round`라는 내장함수를 가지고 있습니다."
            " `round` 함수의 두번째 인자를 사용해야합니다.")
    _solution = CS("return round(num, 2)")

class RoundNdigitsProblem(ThoughtExperiment):

    _solution = """실행 결과를 보면 알 수 있듯이, `ndigits=-1` 은 10자리 반올림. `ndigits=-2`는 100자리 반올림을 뜻합니다. 
    이 기능이 어떻게 유용할까요? Suppose we're dealing with large numbers:

> 필란드 면적이 338,424 km²  
> 그린란드 면적이 2,166,086 km² 일때,

너무 정환한 숫자는 이해하기 어렵게 만듭니다. 

우리는 `round()` 함수에 `ndigits=-3` 옵션을 사용하여 좀 더 간략하게 표현할 수 있습니다.:

> 필란드 면적이 338,000 km²  
> 그린란드 면적이 2,166,000 km²

"""

class PrintPrintProblem(ThoughtExperiment):

    _hint = "Think about what happened when we called `help(abs(-2))` in the tutorial"
    
    _solution = """If you've tried running the code, you've seen that it prints:

    Spam
    None

What's going on here? The inner call to the `print` function prints the string "Spam" of course. The outer call prints the value returned by the `print` function - which we've seen is `None`.

Why do they print in this order? *Python evaluates the arguments to a function before running the function itself*. This means that nested function calls are evaluated from the inside out. Python needs to run `print("Spam")` before it knows what value to pass to the outer `print`."""

class CandySmashingFunctionProblem(FunctionProblem):
    _var = 'to_smash'

    _test_cases = [
           ((10, 2), 0),
           ((10, 3), 1),
           ((10, 4), 2),
           (10, 1),
           (9, 0),
           ((10, 10), 0),
           ((10, 11), 10),
            ]
    _hint = "n_friends라는 변수를 만들고, 기본 값을 설정하세요. n_friends를 이용하여 계산식을 수정하세요."
    _solution = CS(
"""def to_smash(total_candies, n_friends=3):
    return total_candies % n_friends""")

    def _do_check(cls, fn):
        try:
            x = fn(10, 2)
        except TypeError:
            raise Incorrect("`to_smash` 함수는 두개의 인자를 받을 수 있도록 수정 되어야 합니다. (e.g. `to_smash(10, 2)`")
        try:
            x = fn(10)
        except TypeError:
            raise Incorrect("`to_smash` 함수는 하나의 안자만으로 실행 될 수 있도록 수정 되어야 합니다. (e.g. `to_smash(10)`")
        super()._do_check(fn)

# How the heck to test this?
class TimeCallProblem(ThoughtExperiment):
    _var = 'time_call'

    _hint = "You'll need to call `time()` before and after calling the input function in order to measure its running time. The `sleep` function will be very useful for testing."
    _solution = '''Example function body:
```python
t0 = time()
fn(arg)
t1 = time()
elapsed = t1 - t0
return elapsed
```
To test your function, you can run something like `time_call(sleep, 2)` and make sure its return value is close to 2. 
'''

class SlowestCallProblem(ThoughtExperiment):
    _hint = "You'll want to call the function you wrote in the previous question (`time_call`) in the body of `slowest_call`."
    _solution = """
```python
return max(time_call(fn, arg1), time_call(fn, arg2), time_call(fn, arg3))
```

You *could* copy-paste the code you wrote for `time_call` three times with some slight variable changes. But that's highly not recommended. It's more typing, and if you later noticed a bug in `time_call`, you'd have to fix it in 4 places. [Laziness is one of the three great virtues of a programmer.](http://threevirtues.com/)
"""

class SmallestStringyDebug(ThoughtExperiment):
    _solution = (
"""`smallest_stringy_number('10', '2', '3')` is one example of a failure - it evaluates to '10' rather than '2'.

The problem is that when `min` is applied to strings, Python returns the earliest one in *lexicographic order* (i.e. something like the logic used to order dictionaries or phonebooks) rather than considering their numerical value.
""")

class SmallestStringyFix(FunctionProblem):
    _var = 'smallest_stringy_number'
    
    _test_cases =  [
            ( ('1', '2', '3'), '1'),
            ( ('10', '2', '3'), '2'),
            ( ('2', '3', '10'), '2'),
            ( ('-100', '10', '5'), '-100'),
            ]

    _hint = "Remember that `min` can optionally take a `key` argument representing a function to apply to each element before comparing them."
    _solution = CS('return min(s1, s2, s3, key=int)')

SmallestStringyProblem = MultipartProblem(SmallestStringyDebug,
        SmallestStringyFix)

qvars = bind_exercises(globals(), [
    RoundFunctionProblem,
    RoundNdigitsProblem,
    CandySmashingFunctionProblem,
    DummyProblem, # Reading exceptions
    TimeCallProblem,
    SlowestCallProblem,
    PrintPrintProblem,
    SmallestStringyProblem,
    ],
)
__all__ = list(qvars)
