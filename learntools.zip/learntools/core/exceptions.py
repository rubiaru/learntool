
class NotAttempted(Exception):
    pass

class Incorrect(Exception):
    pass

class UserlandExceptionIncorrect(Incorrect):
    """Raised when a user's solution is incorrect because it raised an (unexpected)
    exception when called.
    """
    def __init__(self, exception, args):
        self.wrapped_exception = exception
        self.msg  = ("`{!r}` 인자를 사용하여 함수를 실행할 때, "
                " 다음과 같은 에러가 발생했습니다. **`{}: {}`**").format(
                        args, exception.__class__.__name__, exception)
    def __str__(self):
        return self.msg

class Uncheckable(Exception):
    pass
