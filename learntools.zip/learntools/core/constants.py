# This file defines ____ which we use in courses as a sentinel indicating a user hasn't
# attempted an exercise.

class PlaceholderValue(object):

    def __eq__(self, other):
        return isinstance(other, PlaceholderValue)

    def _repr_markdown_(self):
        """이것은 빈 문자열을 반환합니다. 일부 질문의 시작 코드 셀은 다음과 같습니다.:
            foo = ____
            q1.check()
            foo
        
        """
        return ''

PLACEHOLDER = PlaceholderValue()
