import pandas as pd

from learntools.core import *

reviews = pd.read_csv("lib/input/wine-reviews/winemag-data-130k-v2.csv", index_col=0)

# 1
class SelectDescCol(EqualityCheckProblem):
    _var = 'desc'
    _expected = (
            reviews.description
    )
    #_solution = CS("desc = reviews.description")
    # This behaviour really should have been opt-in, rather than opt-out :/
    show_solution_on_correct = False
    _hint = "Dataframe 객체에서 특정 열을 접근하고 싶다면 `.` 을 이용하세요. 예) reviews.열이름"
    _solution = """
```python
desc = reviews.description
```
또는  
```python
desc = reviews["description"]
```
`desc 변수는 DataFrame 개체인 reviews와 일치하는 인덱스가 있는 Series 객체입니다. 
보통 Dataframe에서 단일 열을 선택하면 Series 객체입니다.
"""

# 2
class FirstDesc(EqualityCheckProblem):
    _var = 'first_description'
    _expected = (
            reviews.description.iloc[0]
    )
    _hint = "reviews.description.iloc를 사용하세요. iloc은 0부터 시작한다는 것을 기억하세요. "
    _solution = """
```python
first_description = reviews.description.iloc[0]
```
reviews.description.iloc[0]

또는 

reviews.description.[0]

도 사용 가능합니다. 

"""

# 3
class FirstRow(EqualityCheckProblem):
    _var = 'first_row'
    _expected = (
            reviews.iloc[0]
    )
    _hint = "reviews.iloc를 사용하세요. iloc은 0부터 시작한다는 것을 기억하세요."
    _solution = CS("first_row = reviews.iloc[0]")

# 4
class FirstDescs(EqualityCheckProblem):
    _var = 'first_descriptions'
    _expected = (
            reviews.description.iloc[:10]
    )
    _hint = "우리는 `loc` or `iloc` 연산자를 사용할 수 있습니다.  **Index-based selection**,  **Label-based selection** 기억나시죠?"
    _solution = """
```python
first_descriptions = reviews.description.iloc[:10]
```
아래 같은 방법도 가능합니다. 

`desc.head(10)` 

또는 

`reviews.loc[:9, "description"]`.    
"""

# 5
class SampleReviews(EqualityCheckProblem):
    _var = 'sample_reviews'
    indices = [1, 2, 3, 5, 8]
    _expected = (
            reviews.loc[indices],
    )
    _hint = "loc`나 `iloc`를 사용하세요. "
    _solution = CS("""\
indices = [1, 2, 3, 5, 8]
sample_reviews = reviews.loc[indices]""")

# 6
class RowColSelect(EqualityCheckProblem):
    _var = 'df'
    cols = ['country', 'province', 'region_1', 'region_2']
    indices = [0, 1, 10, 100]
    _expected = (
            reviews.loc[indices, cols],
    )
    _hint = "loc 를 사용하세요. (열이 문자열이니까 loc를 사용하는게 편합니다.)"
    _solution = CS("""\
cols = ['country', 'province', 'region_1', 'region_2']
indices = [0, 1, 10, 100]
df = reviews.loc[indices, cols]""")

# 7
class RowColSelect2(EqualityCheckProblem):
    _var = 'df'
    cols = ['country', 'variety']
    _expected = (
            reviews.head(100).loc[:,cols],
    )
    _hint = "'loc' 연산자를 사용하여 이 문제를 해결하는 것이 가장 간단합니다. (그러나 'iloc'을 사용하기로 결정했다면 먼저 각 열을 해당하는 정수 값 인덱스로 변환해야 합니다.)"
    _solution = """
```python
cols = ['country', 'variety']
df = reviews.loc[:99, cols]
```
또는 
```python
cols_idx = [0, 11]
df = reviews.iloc[:100, cols_idx]
```
"""

# 8
class ItalianWines(EqualityCheckProblem):
    _var = 'italian_wines'
    _expected = (
            reviews[reviews.country == 'Italy'],
    )
    _hint = "reviews 객체에서 reviews.country == 'Italy' 조건을 사용하세요."
    _solution = CS("italian_wines = reviews[reviews.country == 'Italy']")

# 9
class TopOceanicWines(EqualityCheckProblem):
    _var = 'top_oceania_wines'
    cols = ['country', 'variety']
    _expected = reviews[
                (reviews.country.isin(['Australia', 'New Zealand']))
                & (reviews.points >= 95)
    ]
    _hint = "isin 함수를 활용하세요. 조건이 두개이며 모두 만족해야합니다."
    _solution = CS("""\
top_oceania_wines = reviews.loc[
    (reviews.country.isin(['Australia', 'New Zealand']))
    & (reviews.points >= 95)
]""")

qvars = bind_exercises(globals(), [
    SelectDescCol,
    FirstDesc,
    FirstRow,
    FirstDescs,
    SampleReviews,
    RowColSelect,
    RowColSelect2,
    ItalianWines,
    TopOceanicWines,
    ],
    )
__all__ = list(qvars)
