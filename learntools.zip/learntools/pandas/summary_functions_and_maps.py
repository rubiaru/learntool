import pandas as pd

from learntools.core import *

reviews = pd.read_csv("./lib/input/wine-reviews/winemag-data-130k-v2.csv", index_col=0)

# 1
class MedianPoints(EqualityCheckProblem):
    _var = 'median_points'
    _expected = reviews.points.median()
    _hint = "median() 함수를 사용하세요."
    _solution = CS('median_points = reviews.points.median()')

# 2
class UniqueCountries(CodingProblem):
    _var = 'countries'
    expected_set = set(reviews.country.unique())
    _hint = "unique() 함수를 사용하세요."
    _solution = CS('countries = reviews.country.unique()')

    def check(self, countries):
        # TODO: implement this assert
        #assert_equal_ignoring_order(countries, self.expected_set, self._var)
        assert_len(countries, len(self.expected_set), var=self._var)
        assert set(countries) == self.expected_set, ("잘못된 값입니다.: `{!r}`").format(countries)

# 3
class ReviewsPerCountry(EqualityCheckProblem):
    _var = 'reviews_per_country'
    _expected = reviews.country.value_counts()
    _hint = "value_counts() 함수를 사용하세요.)"
    _solution = CS('reviews_per_country = reviews.country.value_counts()')

# 4
# TODO: This is an exact dupe of something shown in reference notebook
class CenteredPrice(EqualityCheckProblem):
    _var = 'centered_price'
    _expected = reviews.price - reviews.price.mean()
    _hint = "mean() 함수를 활용하세요. (행요소 - 평균)."
    _solution = CS('centered_price = reviews.price - reviews.price.mean()')

# 5
class BargainWine(CodingProblem):
    _var = 'bargain_wine'
    _hint = "idxmax()를 활용하세요. "
    _solution = CS('''\
bargain_idx = (reviews.points / reviews.price).idxmax()
bargain_wine = reviews.loc[bargain_idx, 'title']''')

    def check(self, bargain_wine):
        assert_isinstance(str, bargain_wine, var='bargain_wine')
        # NB: Hard-coding these rather than calculating them dynamically.
        # These two wines are tied for best bargain, each having a points-to-price
        # ratio of 21.5. They'll always get the first one using the idxmax() solution,
        # but may get the Pinot if they use a different method.
        bargains = ['Bandit NV Merlot (California)', 'Cramele Recas 2011 UnWineD Pinot Grigio (Viile Timisului)']
        assert_is_one_of(bargain_wine, bargains, var='bargain_wine')

# 6
class DescriptorCounts(EqualityCheckProblem):
    _var = 'descriptor_counts'
    n_trop = reviews.description.map(lambda desc: "tropical" in desc).sum()
    n_fruity = reviews.description.map(lambda desc: "fruity" in desc).sum()
    _expected = pd.Series([n_trop, n_fruity], index=['tropical', 'fruity'])
    _hint = "map() 함수를 사용하여, 문자열에 `tropical` 단어가 들어간 횟수를 구하세요. 'fruity' 단어에 대해서도 반복합니다. 마지막으로 두 값을 결합한 Series를 만드세요."
    _solution = CS('''\
n_trop = reviews.description.map(lambda desc: "tropical" in desc).sum()
n_fruity = reviews.description.map(lambda desc: "fruity" in desc).sum()
descriptor_counts = pd.Series([n_trop, n_fruity], index=['tropical', 'fruity'])''')

# 7
class StarRatings(EqualityCheckProblem):
    _var = 'star_ratings'
    _hint = """
DataFrame의 행을 입력으로 받아들이고 행에 해당하는 별점을 반환하는 사용자 정의 함수를 작성하여 시작하십시오. 

그런 다음 `DataFrame.apply` 함수를 사용하여, 데이터 세트의 모든 행에 사용자 정의 함수를 적용합니다.


"""
    _solution = CS("""\
def stars(row):
    if row.country == 'Canada':
        return 3
    elif row.points >= 95:
        return 3
    elif row.points >= 85:
        return 2
    else:
        return 1
    
star_ratings = reviews.apply(stars, axis='columns')""")

    def stars_transform(row):
        if row.country == 'Canada':
            return 3
        elif row.points >= 95:
            return 3
        elif row.points >= 85:
            return 2
        else:
            return 1
    
    # NB: This is kind of slow. Might want to lazy-initialize.
    _expected = reviews.apply(stars_transform, axis='columns')


qvars = bind_exercises(globals(), [
    MedianPoints,
    UniqueCountries,
    ReviewsPerCountry,
    CenteredPrice,
    BargainWine,
    DescriptorCounts,
    StarRatings,
    ],
    )
__all__ = list(qvars)
