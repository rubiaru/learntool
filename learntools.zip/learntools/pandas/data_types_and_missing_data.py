import pandas as pd

from learntools.core import *

reviews = pd.read_csv("./lib/input/wine-reviews/winemag-data-130k-v2.csv", index_col=0)

class PointsDtype(EqualityCheckProblem):
    _var = 'dtype'
    _expected = reviews.points.dtype
    _hint = "`dtype` DataFrame 이나 Series 의 속성 값입니다."
    _solution = CS("dtype = reviews.points.dtype")

class StrPoints(EqualityCheckProblem):
    _var = 'point_strings'
    _expected = reviews.points.astype(str)
    _hint = "'astype()' 함수를 사용하여 열이 갖고 있는 타입을 다른 타입으로 변환합니다."
    _solution = CS("point_strings = reviews.points.astype(str)")

class CountMissingPrices(EqualityCheckProblem):
    _var = 'n_missing_prices'
    _expected = reviews.price.isnull().sum()
    _hint = "`pd.isnull()` 함수를 사용하세요."
    _solution = CS("""\
missing_price_reviews = reviews[reviews.price.isnull()]
n_missing_prices = len(missing_price_reviews)
# 대안) boolean 유형의 series는 참(True)은 1 거짓(False)은 0으로 다뤄진다.
n_missing_prices = reviews.price.isnull().sum()
# 또는
n_missing_prices = pd.isnull(reviews.price).sum()
""")
    

class ReviewsPerRegion(CodingProblem):
    _solution = CS("reviews_per_region = reviews.region_1.fillna('Unknown').value_counts().sort_values(ascending=False)")
    _hint = "`fillna()`, `value_counts()`, `sort_values()` 함수를 활용하세요."
    _var = 'reviews_per_region'
    
    def check(self, reviews_per_region):
        _expected = reviews.region_1.fillna('Unknown').value_counts().sort_values(ascending=False)
        assert all(reviews_per_region.values == _expected.values), ('Create a Series counting the number of times each value occurs in the `region_1` field.  Replace missing values with `Unknown`, and sort in descending order.')
        

qvars = bind_exercises(globals(), [
    PointsDtype,
    StrPoints,
    CountMissingPrices,
    ReviewsPerRegion,
    ],
    )
__all__ = list(qvars)
